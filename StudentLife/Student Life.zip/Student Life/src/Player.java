/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author polinati
 */
import java.util.Random;

public class Player extends Character {

    protected int intelligence;
    protected int charisma;
    protected int socialEXP;
    protected int studyEXP;
    protected boolean mood;
    protected Location currentLocation;
    protected Activity currentActivity;
    protected Location previousLocation;
    protected String name;

    public Player(Location defaultLocation, boolean mood) {
        this.name = "";
        this.currentLocation = defaultLocation;
        this.socialEXP = 0;
        this.studyEXP = 0;
        this.currentActivity = null;
        this.previousLocation = null;
        this.mood = mood;
    }
    
    public void setName (String name)
    {
        this.name += name;
    }
    
    public String getName (){
        return this.name;
    }
    
    // Sets type of character according to player’s choice
    public void setTitle (String title)
    {
        Random stats = new Random();
        if (title.equals("Nerd")) {
            this.intelligence = stats.nextInt(5) + 10;
            this.charisma = 20 - this.intelligence;
        }

        if (title.equals("Party Animal")) {
            this.charisma = stats.nextInt(5) + 10;
            this.intelligence = 20 - this.charisma;
        }

        if (title.equals("Typical")) {
            this.intelligence = 10;
            this.charisma = 10;
        }
        
        if (!title.equals("Nerd")&&!title.equals("Typical")&&!title.equals("Party Animal")){
            this.intelligence = 10;
            this.charisma = 10;
        }
    }

    public void setLocation(Location location) {
        this.previousLocation = this.currentLocation;
        this.currentLocation = location;
    }
    
    public Location getPreviousLocation(){
        return this.previousLocation;
    }
    
    public Location returnLocation()
    {
        return this.currentLocation;
    }
    
    public void setCurrentActivity(Activity activity) {
        this.currentActivity = activity;
    }
    
    public Activity getCurrentActivity(){
        return this.currentActivity;
    } 
    
    public void increaseStats(Activity activity){
        if (this.intelligence < 20) {
            this.intelligence += activity.bonusINT;
        }
        if (this.charisma < 20) {
            this.charisma += activity.bonusCHA;
        }
    }
    
    public String getMood() {
        if (mood) {
            return "Mood: Happy";
        } else {
            return "Mood: Sad";
        }
    }

    // Used for testing
    public String toString() {
        return "Name: " + this.name + "\n"
                //+ "Current Location: " + this.currentLocation + "\n"
                + "Intelligence: " + this.intelligence + "\n"
                + "Charisma: " + this.charisma + "\n"
                + "Social EXP: " + this.socialEXP + "\n"
                + "Study EXP:" + this.studyEXP + "\n";
                //+ getMood();

    }
   
    public String stats() {
        return "socialEXP: " + this.socialEXP + ", studyEXP: " + this.studyEXP + ", INT: " + this.intelligence + ", CHA: " + this.charisma;
    }

}
