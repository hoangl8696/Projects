// This is not an exercise but a "sandbox" where you can freely test
// whatever you want
import java.util.Scanner;
public class Application {

    public static void main(String[] args) {
        
        Interpreter game = new Interpreter ();
        game.start();
    

        // Write the code here. You can run the code by 
        // selecting Run->Run File from the menu or by pressing Shift+F6
        
        //Scanner readerInput = new Scanner ();
        //int borrow = Integer.parseInt(reader.nextLine());
        //interperter.comand (borrow)
        
        
        
    }
}
