/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author polinati
 */

import java.util.ArrayList;

public class Location {
    
    protected String name;
    protected ArrayList <String> openHours; // List of day times when location is allowed to be visited
    protected String description;
    protected ArrayList <Location> nextLocation; // List of locations player can go from current one
    protected ArrayList <Activity> locationActivity; // List of initial activities for location
    protected int checker; // Checks if location is final and player can,t go further
    
    public Location (String name, int checker, ArrayList<String> openHours)
    {
        this.name = name;
        this.openHours = openHours;
        this.description = "";
        this.nextLocation = new ArrayList<Location>();
        this.locationActivity = new ArrayList<Activity>();
        this.checker = checker;
    }
    
    public void addNext (Location location)
    {
        this.nextLocation.add(location);
    }
   
    
    public void setOpenHours (String openHours)
    {
        this.openHours.add(openHours);
    }
    
    public void printOpenHours ()
    {
        for (String hours : this.openHours)
        {
            System.out.println(hours);
        }
    }
    
    public String getLocationName () {
        return this.name;
    }
    
    public void inputDescription (String input)
    {
        this.description += input;
    }
    
    public String printDescription()
    {
        return this.description;
    }
            
        
    public void addActivity(Activity activity){
        locationActivity.add(activity);
    }
    
    public ArrayList<Activity> getActivities(){
        return this.locationActivity;
    }
    
    public ArrayList<Location> getNextLocation()
    {
        return this.nextLocation;
    }
    
    public void changeLocationName (String name)
    {
        this.name = name;
    }
    
    public boolean isOpen (String timeNow)
    {
        if (this.openHours.contains(timeNow))
        {
            return true;
        }
        return false;
    }
    
    public boolean isFinal () {
        if (this.checker == 1) {
            return true;
        } 
        return false;
    }    
}
