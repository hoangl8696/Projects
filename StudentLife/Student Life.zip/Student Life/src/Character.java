/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author polinati
 */
public class Character {
    protected String name;
    protected String currentLocation;
    
    public void setLocation(String location)
    {
        this.currentLocation = location;
    }
    
    public String getName()
    {
      return this.name;  
    }
    
    public String getLocation()
    {
        return this.currentLocation;
    }
}
