/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author polinati
 */
// To change amount of days until the Final Event change line XXX.
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Collections;

public class Interpreter {

    // Initializing locations
    Location Home = new Location("Home", 0, new ArrayList<String>(Arrays.asList("Morning", "Day", "Evening", "Night")));
    Location Club = new Location("Club", 0, new ArrayList<String>(Arrays.asList("Evening", "Night")));
    Location School = new Location("School", 0, new ArrayList<String>(Arrays.asList("Morning", "Day", "Evening")));
    Location Cafeteria = new Location("Cafeteria", 1, new ArrayList<String>(Arrays.asList("Morning", "Day", "Evening")));
    Location Library = new Location("Library", 1, new ArrayList<String>(Arrays.asList("Morning", "Day", "Evening")));
    Location Finnish = new Location("Finnish Classroom", 1, new ArrayList<String>(Arrays.asList("Morning", "Day", "Evening")));
    Location Maths = new Location("Maths Classroom", 1, new ArrayList<String>(Arrays.asList("Morning", "Day", "Evening")));
    Location Games = new Location("Games Classroom", 1, new ArrayList<String>(Arrays.asList("Morning", "Day", "Evening")));
    Location Bar = new Location("Bar", 1, new ArrayList<String>(Arrays.asList("Evening", "Night")));
    Location DanceFloor = new Location("Dancefloor", 1, new ArrayList<String>(Arrays.asList("Evening", "Night")));
    Location Sofas = new Location("Sofas", 1, new ArrayList<String>(Arrays.asList("Evening", "Night")));
    Location Room = new Location("Your Room", 1, new ArrayList<String>(Arrays.asList("Morning", "Day", "Evening", "Night")));
    Location Kitchen = new Location("Kitchen", 1, new ArrayList<String>(Arrays.asList("Morning", "Day", "Evening", "Night")));
    Location Final = new Location("Final Event", 1, new ArrayList<String>(Arrays.asList("Morning", "Day", "Evening", "Night")));

    // Initializing activities in Your Room
    Activity Procrastinate = new Activity(0, 0, 0, 0, true, false, 1);
    Activity Sleep = new Activity(0, 0, 0, 0, true, true, 1);
    Activity Play = new Activity(0, 0, 0, 0, true, true, 1);
    Activity Homework = new Activity(0, 500, 0, 0, true, true, 1);
    Activity CallFriend = new Activity(300, 0, 0, 0, true, true, 1);
    Activity ChatFriends = new Activity(200, 0, 0, 0, true, true, 1);
    Activity CatVideos = new Activity(0, 0, 0, 0, true, true, 1);
    Activity Robot = new Activity(0, 1000, 0, 0, true, true, 1);
    Activity Shower = new Activity(0, 0, 0, 0, true, true, 1);
    Activity Forest = new Activity(0, 0, 0, 0, true, true, 1);
    Activity Kalsaricannit = new Activity(0, 0, 0, 0, true, true, 1);

    // Initializing activities in Kitchen
    Activity Cook = new Activity(0, 0, 0, 0, true, true, 1);
    Activity TalkToFlatmate = new Activity(200, 0, 0, 0, true, true, 1);
    Activity Clean = new Activity(0, 0, 0, 0, true, true, 1);

    // Initializing activities in Buy a drink
    Activity BarBuyChineseShot = new Activity(0, 0, 0, 0, true, false, 8);
    Activity BarBuyMyFairLady = new Activity(0, 0, 0, 1, true, true, 1);
    Activity BarBuyMatrixShot = new Activity(false, true, 0);
    Activity Red = new Activity(0, 0, 2, 0, true, true, 1);
    Activity Blue = new Activity(0, 0, 0, 0, true, false, 1);
    Activity BarBuyJagerBomb = new Activity(300, 0, 0, 0, true, true, 1);
    Activity BarBuyItalianCurse = new Activity(-100, -100, 0, 0, true, false, 1);
    Activity BarBuyRyeMeRiver = new Activity(-200, 0, 0, 0, true, false, 1);
    Activity BarBuyMintToBe = new Activity(500, 0, 0, 0, true, true, 1);
    Activity BarBuyCarolinaRipperKiss = new Activity(500, 0, 0, 1, true, true, 1);
    Activity BarBuyDeathInTheAfternoon = new Activity(-200, -100, 0, 0, true, false, 1);
    Activity BarBuyRedLongTail = new Activity(100, 0, 0, 0, true, true, 1);
    Activity BarBuyNeverDrinkAndDerive = new Activity(0, 300, 0, 0, true, true, 1);
    Activity BarBuyRoundOfBeers = new Activity(1000, 0, 0, 1, true, true, 1);
    Activity BarBuyMysticBoat = new Activity(700, 0, 0, 1, true, true, 1);

    // Initializing activities in Dancefloor
    Activity DanceWildly = new Activity(400, 0, 0, 0, true, true, 1);
    Activity DanceRobotically = new Activity(300, 0, 0, 0, true, false, 1);
    Activity DanceTryOrangeCoverall = new Activity(1000, 0, 0, 0, true, true, 1, 0, 21);
    Activity Drugs = new Activity(700, -200, 0, 0, true, true, 1);
    Activity DanceWithFriend = new Activity(300, 0, 0, 0, true, true, 1);
    Activity DanceTryGinger = new Activity(500, 0, 0, 0, true, true, 1, 0, 11);
    Activity DancePretend = new Activity(0, 0, 0, 0, true, false, 1);

    // Initializing activities in Sofas
    Activity SofasSuit = new Activity(700, 400, 0, 0, true, true, 1, 11, 0);
    Activity SofasProvocative = new Activity(1500, 0, 0, 0, true, true, 1, 0, 15);
    Activity SofasUpsetGirl = new Activity(700, 0, 0, 0, true, true, 1, 0, 8);
    Activity SofasGuyHat = new Activity(800, 0, 0, 0, true, true, 1, 0, 12);
    Activity SofasKha = new Activity(300, 0, 0, 0, true, true, 1, 12, 0);

    // Initializing common activities for Classrooms
    Activity WatchMovieNo = new Activity(0, -100, 0, 0, true, false, 1);
    Activity WatchMovieYes = new Activity(0, -100, 0, 0, true, true, 1);

    // Initializing activities in Maths Classroom
    Activity MathStudy = new Activity(0, 700, 0, 0, true, true, 1);
    Activity MathTest01 = new Activity(false, true, 0);
    Activity MathTest01a = new Activity(0, 0, 0, 0, true, false, 1);
    Activity MathTest01b = new Activity(0, 1200, 1, 0, true, true, 1);
    Activity MathTest01c = new Activity(0, 0, 0, 0, true, true, 1);

    Activity Class9GAG = new Activity(0, -300, 0, 0, true, true, 1);
    Activity ClassHearthstone = new Activity(300, -500, 0, 0, true, true, 1);

    // Initializing activities in Finnish Classroom
    Activity FinnishStudy = new Activity(0, 1000, 0, 0, true, true, 1);
    Activity FinnishTest = new Activity(false, true, 0);
    Activity FinnishTest01a = new Activity(0, 0, 0, 0, true, false, 1);
    Activity FinnishTest01b = new Activity(0, 0, 0, 0, true, false, 1);
    Activity FinnishTest01c = new Activity(0, 1200, 1, 0, true, true, 1);

    // Initializing activities in Games Classroom
    Activity GamesTest = new Activity(false, true, 0);
    Activity GamesTest01a = new Activity(0, 0, 0, 0, true, false, 1);
    Activity GamesTest01b = new Activity(0, 1200, 1, 0, true, true, 1);
    Activity GamesTest01c = new Activity(0, 0, 0, 0, true, false, 1);

    // Initializing activities in Library 
    Activity LibraryHomework = new Activity(0, 500, 0, 0, true, true, 1);
    Activity TalkLibrarian = new Activity(100, 0, 0, 0, true, false, 1);
    Activity ReadBook = new Activity(false, true, 0);
    Activity ReadBookHowToWinFriends = new Activity(0, 0, 0, 1, true, true, 1);
    Activity ReadBookJavaGently = new Activity(0, 300, 0, 0, true, true, 1); // This is the real book by the way
    Activity ReadBookArtProgramming = new Activity(0, 0, 1, 0, true, true, 1);
    Activity ReadBookByteOfPython = new Activity(0, 300, 0, 0, true, true, 1); // This one is also real
    Activity ReadBookPragmaticProgrammer = new Activity(0, 700, 0, 0, true, true, 1);
    Activity ReadBookScrum = new Activity(0, 300, 0, 0, true, true, 1);
    Activity ReadBookKalevala = new Activity(0, 200, 0, 0, true, true, 1);
    Activity ReadBookMarryFinnish = new Activity(300, 100, 0, 0, true, true, 1); // Another real book
    Activity ReadBookAppliedMinds = new Activity(0, 400, 0, 0, true, true, 1);
    Activity ReadBookMindForNumbers = new Activity(0, 300, 0, 0, true, true, 1);

    // Initializing activities in Cafeteria
    Activity EatAlone = new Activity(0, 200, 0, 0, true, false, 1);
    Activity EatFriends = new Activity(300, 0, 0, 0, true, true, 1);
    Activity SitThirdYear = new Activity(300, 400, 0, 0, true, true, 1, 12, 0);
    Activity SitItalian = new Activity(0, 0, 0, 0, true, false, 1);
    Activity SitVietnamese = new Activity(0, 0, 0, 0, true, false, 1);
    Activity SitDarkHair = new Activity(0, 0, 0, 0, true, true, 1, 0, 9);

    //Activity GoBack = new Activity(0, 0, 0, 0, true);
    Activity Hold = new Activity(false, true, 0);

    ArrayList<String> whereToGo;

    Player player = new Player(School, true);

    Time time = new Time();

    Scanner command = new Scanner(System.in);

    Random randomSeeder = new Random();

    Descriptions description = new Descriptions();

    int seed = 0;

    public Interpreter() {

    }

    public void start() {

        // Linking locations to each other
        Home.addNext(Room);
        Home.addNext(Kitchen);
        Home.addNext(School);
        Home.addNext(Club);

        School.addNext(Finnish);
        School.addNext(Maths);
        School.addNext(Games);
        School.addNext(Library);
        School.addNext(Cafeteria);
        School.addNext(Home);
        School.addNext(Club);

        Finnish.addNext(School);
        Maths.addNext(School);
        Games.addNext(School);
        Library.addNext(School);
        Cafeteria.addNext(School);

        Club.addNext(DanceFloor);
        Club.addNext(Bar);
        Club.addNext(Sofas);
        Club.addNext(Home);

        Bar.addNext(Club);
        DanceFloor.addNext(Club);

        //Adding activities
        Room.addActivity(Play);
        Room.addActivity(Sleep);
        Room.addActivity(Homework);
        Room.addActivity(CallFriend);
        Room.addActivity(CatVideos);
        Room.addActivity(Robot);
        Room.addActivity(Procrastinate);
        Room.addActivity(ChatFriends);
        Room.addActivity(Shower);
        Room.addActivity(Forest);
        Room.addActivity(Kalsaricannit);

        Kitchen.addActivity(Cook);
        Kitchen.addActivity(TalkToFlatmate);
        Kitchen.addActivity(Clean);

        Maths.addActivity(WatchMovieNo);
        Maths.addActivity(MathStudy);
        Maths.addActivity(Class9GAG);
        Maths.addActivity(ClassHearthstone);
        Maths.addActivity(MathTest01);
        MathTest01.addNextActivity(MathTest01a);
        MathTest01.addNextActivity(MathTest01b);
        MathTest01.addNextActivity(MathTest01c);

        Finnish.addActivity(FinnishStudy);
        Finnish.addActivity(Class9GAG);
        Finnish.addActivity(WatchMovieYes);
        Finnish.addActivity(ClassHearthstone);
        Finnish.addActivity(FinnishTest);
        FinnishTest.addNextActivity(FinnishTest01a);
        FinnishTest.addNextActivity(FinnishTest01b);
        FinnishTest.addNextActivity(FinnishTest01c);

        Games.addActivity(WatchMovieNo);
        Games.addActivity(Class9GAG);
        Games.addActivity(ClassHearthstone);
        Games.addActivity(GamesTest);
        GamesTest.addNextActivity(GamesTest01a);
        GamesTest.addNextActivity(GamesTest01b);
        GamesTest.addNextActivity(GamesTest01c);

        Library.addActivity(LibraryHomework);
        Library.addActivity(ReadBook);
        Library.addActivity(TalkLibrarian);
        ReadBook.addNextActivity(ReadBookHowToWinFriends);
        ReadBook.addNextActivity(ReadBookJavaGently);
        ReadBook.addNextActivity(ReadBookArtProgramming);
        ReadBook.addNextActivity(ReadBookByteOfPython);
        ReadBook.addNextActivity(ReadBookPragmaticProgrammer);
        ReadBook.addNextActivity(ReadBookScrum);
        ReadBook.addNextActivity(ReadBookKalevala);
        ReadBook.addNextActivity(ReadBookMarryFinnish);
        ReadBook.addNextActivity(ReadBookAppliedMinds);
        ReadBook.addNextActivity(ReadBookMindForNumbers);

        Cafeteria.addActivity(EatAlone);
        Cafeteria.addActivity(EatFriends);
        Cafeteria.addActivity(SitThirdYear);
        Cafeteria.addActivity(SitItalian);
        Cafeteria.addActivity(SitDarkHair);

        Bar.addActivity(BarBuyChineseShot);
        Bar.addActivity(BarBuyItalianCurse);
        Bar.addActivity(BarBuyMyFairLady);
        Bar.addActivity(BarBuyMatrixShot);
        Bar.addActivity(BarBuyJagerBomb);
        Bar.addActivity(BarBuyRyeMeRiver);
        Bar.addActivity(BarBuyMintToBe);
        Bar.addActivity(BarBuyCarolinaRipperKiss);
        Bar.addActivity(BarBuyDeathInTheAfternoon);
        Bar.addActivity(BarBuyRedLongTail);
        Bar.addActivity(BarBuyNeverDrinkAndDerive);
        Bar.addActivity(BarBuyMysticBoat);
        Bar.addActivity(BarBuyRoundOfBeers);

        DanceFloor.addActivity(DanceWildly);
        DanceFloor.addActivity(DanceRobotically);
        DanceFloor.addActivity(DanceTryOrangeCoverall);
        DanceFloor.addActivity(Drugs);
        DanceFloor.addActivity(DanceWithFriend);
        DanceFloor.addActivity(DanceTryGinger);
        DanceFloor.addActivity(DancePretend);

        Sofas.addActivity(SofasSuit);
        Sofas.addActivity(SofasProvocative);
        Sofas.addActivity(SofasUpsetGirl);
        Sofas.addActivity(SofasGuyHat);
        Sofas.addActivity(SofasKha);

        BarBuyMatrixShot.addNextActivity(Red);
        BarBuyMatrixShot.addNextActivity(Blue);

        // Adding descriptions for lcoations
        School.inputDescription(description.metropolia);
        Home.inputDescription(description.home);
        Library.inputDescription(description.library);
        Cafeteria.inputDescription(description.cafeteria);
        Club.inputDescription(description.Tiger);
        Maths.inputDescription(description.MathClassroom);
        Finnish.inputDescription(description.FinnishClassroom);
        Games.inputDescription(description.GamesClassroom);
        DanceFloor.inputDescription(description.dancefloor);

        // Adding descriptions for activities
        Procrastinate.setDescription("Procrastinate", "start");
        Procrastinate.setDescription(description.procrastinate, "end");
        Sleep.setDescription("Sleep", "start");
        Sleep.setDescription(description.sleep, "end");
        Play.setDescription("Play video games", "start");
        Play.setDescription(description.play, "end");
        Homework.setDescription("Do homework", "start");
        Homework.setDescription(description.homework, "end");
        Cook.setDescription("Cook", "start");
        Cook.setDescription(description.cook, "end");
        Clean.setDescription("Clean up house", "start");
        Clean.setDescription(description.clean, "end");
        TalkToFlatmate.setDescription("Talk to your flatmate", "start");
        TalkToFlatmate.setDescription(description.talkToFlatmate, "end");
        CallFriend.setDescription("Call a friend", "start");
        CallFriend.setDescription(description.callFriend, "end");
        ChatFriends.setDescription("Chat with friends", "start");
        ChatFriends.setDescription(description.chatFriends, "end");
        CatVideos.setDescription("Watch funny cat videos", "start");
        CatVideos.setDescription(description.catVideos, "end");
        Robot.setDescription("Build your own Lego Robot", "start");
        Shower.setDescription("Go to the bathroom to take a shower", "start");
        Shower.setDescription(description.shower, "end");
        Forest.setDescription("Instead of staying at home go to the forest", "start");
        Forest.setDescription(description.forest, "end");
        Kalsaricannit.setDescription("Kalsaricannit", "start");
        Kalsaricannit.setDescription("You stayed at home drinking by yourself at your house in your undwear with no intention of going out.\n"
                + "Feel like a true Finn after.\n", "end");

        Class9GAG.setDescription("Check 9GAG", "start");
        Class9GAG.setDescription(description.NineGAG, "end");
        ClassHearthstone.setDescription("Play Hearthstone on your laptop", "start");
        ClassHearthstone.setDescription(description.Hearthstone, "end");

        MathStudy.setDescription("Concentrate and attempt to exercise", "start");
        MathTest01.setDescription("Take a test", "start");
        MathTest01.setDescription("====", "end");
        MathTest01.setDescription("Calculate: 3+3x3-3+3", "condition");
        MathTest01a.setDescription("6", "start"); //Shazam said if it’s not 6, he’ll quit engineering
        MathTest01a.setDescription("Wrong answer!", "end");
        MathTest01b.setDescription("12", "start"); //I said it’s 12, but he can stay 
        MathTest01b.setDescription("Right answer!", "end");
        MathTest01c.setDescription("18", "start");
        MathTest01c.setDescription("Wrong answer!", "end");

        GamesTest.setDescription("Take a test", "start");
        GamesTest.setDescription("What is the object-oriented way to become wealthy?", "condition");
        GamesTest01a.setDescription("Abstraction", "start");
        GamesTest01a.setDescription("Wrong answer!", "end");
        GamesTest01b.setDescription("Inheritance", "start");
        GamesTest01a.setDescription("Right answer!", "end");
        GamesTest01c.setDescription("Polymorphism", "start");
        GamesTest01c.setDescription("Wrong answer!", "end");

        FinnishStudy.setDescription("Concentrate and attempt to exercise", "start");
        FinnishTest.setDescription("Take a test", "start");
        FinnishTest.setDescription("How do you order two cheeseburgers in Finnish MacDonals?", "condition");
        FinnishTest01a.setDescription("Due cheeseburger per favore", "start");
        FinnishTest01b.setDescription("Два чизбургера, плиз.", "start");
        FinnishTest01c.setDescription("Kaksi juusto, kiitos.", "start");

        WatchMovieNo.setDescription("Watch a movie", "start");
        WatchMovieNo.setDescription("Hahaha! In this class? I’d like to see you try!\n", "end");
        WatchMovieYes.setDescription("Watch a movie", "start");
        WatchMovieYes.setDescription("Now you finally know how 'The Guardians of the Galaxy' ended.\n", "end");

        EatAlone.setDescription("Eat alone and study", "start");
        EatAlone.setDescription(description.eatAlone, "end");
        EatFriends.setDescription("Eat with friends and chat", "start");
        EatFriends.setDescription("One hour passed as a minute. You discussed your friend’s new haircut, last Birthday party and settled\n"
                + "plans for this week.\n", "end");
        SitThirdYear.setDescription("Sit next to the third year student", "start");
        SitThirdYear.setDescription(description.thirdYear, "end");
        SitThirdYear.setDescription(description.thirdYearFail, "fail");
        SitItalian.setDescription("Sit next to Italian guy", "start");
        SitItalian.setDescription(description.sitItalian, "end");
        SitVietnamese.setDescription("Sit next to a Vietnamese guy", "start");
        SitVietnamese.setDescription(description.sitVietnamese, "end");
        SitDarkHair.setDescription("Sit next to dark haired girl", "start");
        SitDarkHair.setDescription(description.sitDarkHair, "end");
        SitDarkHair.setDescription(description.sitDarkHairFail, "fail");

        BarBuyChineseShot.setDescription("Chinese shot", "start");
        BarBuyChineseShot.setDescription("You don’t know what it was. But you blacked out for two whole days.", "end");
        BarBuyItalianCurse.setDescription("Italian curse", "start");
        BarBuyItalianCurse.setDescription("You feel tired and extremly lazy. You leave early and go home, however next day you don’t feel like going to school and miss classes.", "end");
        BarBuyMyFairLady.setDescription("My Fair Lady", "start");
        BarBuyJagerBomb.setDescription("Jager Bomb", "start");
        BarBuyJagerBomb.setDescription("Your best friend suddenly appears next to you and pays for your Jager Bomb.", "end");
        BarBuyRyeMeRiver.setDescription("Rye Me A River", "start");
        BarBuyRyeMeRiver.setDescription("Suddenly your ex appears right next to you in a line. Even after weeks passed it still hurts. You feel sad.", "end");
        BarBuyMintToBe.setDescription("Mint To Be", "start");
        BarBuyMintToBe.setDescription("While you were waiting in the line your long time crush started talking to you. You leave the Bar together", "end");
        BarBuyCarolinaRipperKiss.setDescription("Carolina Ripper Kiss", "start");
        BarBuyCarolinaRipperKiss.setDescription("Apparently this drink is for those who likes it spicy. Everyone who was in the Club will remember you after this night.", "end");
        BarBuyDeathInTheAfternoon.setDescription("Death In The Afternoon", "start");
        BarBuyDeathInTheAfternoon.setDescription("Why would you ever choose a drink with such name? It speaks for itself. You don’t remember anything happened to you that day.", "end");
        BarBuyRedLongTail.setDescription("Red Long Tail", "start");
        BarBuyRedLongTail.setDescription("Your Vietnamese friend insisted that you should try this drink. For the sake of your friendship and to explore another culture traditions you went for it.", "end");
        BarBuyNeverDrinkAndDerive.setDescription("Never Drink And Derive", "start");
        BarBuyNeverDrinkAndDerive.setDescription("Mito was right. It was a bad idea.", "end");
        BarBuyNeverDrinkAndDerive.setDescription("You feel smarter.", "end");
        BarBuyMysticBoat.setDescription("Mystic Boat", "start");
        BarBuyMysticBoat.setDescription("You don’t know what the hell has happened, but you found yourself on the boat"
                + "in the middle of the river. \nSomehow you managed to get out of there and return to the Bar."
                + "It made a hilarious story: next week \neveryone was discussing it. You became famous.", "end");
        BarBuyRoundOfBeers.setDescription("A round of beers for everyone", "start");
        BarBuyRoundOfBeers.setDescription("Beers for everyone! You are scared to even think about how much did it cost to you. At least you got a membership card after it.", "end");
        BarBuyMatrixShot.setDescription("Matrix Shot", "start");
        Red.setDescription("Choose a red one.", "start");
        Blue.setDescription("Choose a blue one.", "start");

        DanceWildly.setDescription("Dance wildly", "start");
        DanceWildly.setDescription(description.danceWildly, "end");
        DanceRobotically.setDescription("Dance robotically", "start");
        DanceRobotically.setDescription(description.danceRobotically, "end");
        DanceTryOrangeCoverall.setDescription("Try to dance with a guy wearing neon orange coverall", "start");
        DanceTryOrangeCoverall.setDescription(description.orangeCoverallFail, "fail");
        Drugs.setDescription("Take drugs", "start");
        Drugs.setDescription(description.drugs, "end");
        DanceWithFriend.setDescription("Dance with a friend", "start");
        DanceWithFriend.setDescription(description.danceWithFriend, "end");
        DanceTryGinger.setDescription("Try dancing with a ginger girl", "start");
        DanceTryGinger.setDescription(description.ginger, "end");
        DanceTryGinger.setDescription(description.gingerFail, "fail");
        DancePretend.setDescription("Pretend to dance", "start");
        DancePretend.setDescription(description.dancePretend, "end");

        SofasSuit.setDescription("Talk to an intelligent guy wearing a suit", "start");
        SofasSuit.setDescription(description.suit, "end");
        SofasSuit.setDescription(description.suitFail, "fail");
        SofasUpsetGirl.setDescription("Talk to an upset girl wearing a small funny hat", "start");
        SofasUpsetGirl.setDescription(description.upsetGirl, "end");
        SofasUpsetGirl.setDescription(description.upsetGirlFail, "fail");
        SofasGuyHat.setDescription("Talk to a guy wearing a hat", "start");
        SofasGuyHat.setDescription(description.guyHat, "end");
        SofasGuyHat.setDescription(description.guyHatFail, "fail");
        SofasKha.setDescription("Talk to a bushy haired guy wearing glasses", "start");
        SofasKha.setDescription(description.Kha, "end");
        SofasKha.setDescription(description.KhaFail, "fail");

        SofasProvocative.setDescription("Talk to a girl wearing provocative dress", "start");
        SofasProvocative.setDescription(description.provocative, "end");
        SofasProvocative.setDescription(description.provocativeFail, "fail");

        TalkLibrarian.setDescription("Talk to the librarian", "start");
        TalkLibrarian.setDescription(description.talkLibrarian, "end");
        LibraryHomework.setDescription("Work on your homework", "start");
        LibraryHomework.setDescription(description.libraryHomework, "end");
        ReadBook.setDescription("Read a book", "start");
        ReadBook.setDescription(description.read, "condition");
        ReadBookHowToWinFriends.setDescription("'How to Win Friends and Influence People' by Dale Carnegie", "start");
        ReadBookHowToWinFriends.setDescription("Now you are ready to be the person everyone wants to be friends with.", "end");
        ReadBookJavaGently.setDescription("'Java Gently' by Judith Mary Bishop", "start");
        ReadBookJavaGently.setDescription(description.book, "end");
        ReadBookArtProgramming.setDescription("'The Art of Computer Programming' by Donald Knuth", "start");
        ReadBookArtProgramming.setDescription("You have known the art. " + description.book, "end");
        ReadBookByteOfPython.setDescription("'Byte of Python' by Swaroop C.H.", "start");
        ReadBookByteOfPython.setDescription(description.book, "end");
        ReadBookPragmaticProgrammer.setDescription("'The Pragmatic Programmer' by Andy Hunt and Dave Thomas", "start");
        ReadBookPragmaticProgrammer.setDescription(description.book, "end");
        ReadBookScrum.setDescription("'Scrum: The Art of Doing Twice the Work in Half the Time' by Jeff Sutherland", "start");
        ReadBookKalevala.setDescription("'Kalevala' by Elias Lönnrot'", "start");
        ReadBookKalevala.setDescription(description.book, "end");
        ReadBookMarryFinnish.setDescription("'How to Marry a Finnish Girl - Everything You Want to Know about Finland, that Finns Won't Tell You' by Phil Schwarzmann", "start");
        ReadBookMarryFinnish.setDescription(description.book, "end");
        ReadBookAppliedMinds.setDescription("'Apllied Minds: How Engineers Think' by Guruprasad Madhavan", "start");
        ReadBookAppliedMinds.setDescription(description.book, "end");
        ReadBookMindForNumbers.setDescription("'A Mind for Numbers' by Barbara Oakley", "start");
        ReadBookMindForNumbers.setDescription(description.book, "end");

        player.currentActivity = Hold;

        String playerInput = "";
        int playerMenuInput = 0;

        // Printing Menu loop
        while (playerMenuInput != 1) {
            printMenu();
            try {
                System.out.print("Type in command: ");
                playerMenuInput = Integer.parseInt(command.nextLine());
                System.out.println("" + "\n");
                switch (playerMenuInput) {
                    case 1: {
                        System.out.println("Character creation" + "\n");
                        System.out.print("Choose your name: ");
                        playerInput = command.nextLine();
                        player.setName(playerInput);
                        System.out.println("");
                        System.out.print("Choose your character - Typical, Nerd, Party Animal: ");
                        playerInput = command.nextLine();
                        player.setTitle(playerInput);
                        System.out.println(player);
                        break;
                    }
                    case 2: {
                        printHelp();
                        System.out.print("Type anything to go back to the main menu: ");
                        playerInput = command.nextLine();
                        break;
                    }
                    case 3: {
                        System.exit(0);
                    }
                }
            } catch (Exception e) {
                System.out.println("Invalid command, please type again!");
            }
        }

        // MAIN LOOP
        while (!isEligible(time)) {
            printer(player);
            System.out.print("Type in command, type quit to exit: ");
            try {
                playerInput = command.nextLine();
                if (playerInput.equals("quit")) {
                    break;
                }
                command(Integer.parseInt(playerInput), player);
            } catch (Exception e) {
                System.out.println("Invalid command. Choose again: ");
            }
        }
            System.out.println(description.finalEvent);
            System.out.println(description.MathExam);
            System.out.print("Type in command: ");
            playerInput = command.nextLine();
            switch (Integer.parseInt(playerInput)) {

                case 2:

                    System.out.println("Right answer!");
                    player.studyEXP += 2000;
                    break;

                default:

                    System.out.println("Wrong answer!");

            }
            System.out.println("Let’s proceed to the next exam");
            System.out.println(description.GamesExam);
            System.out.print("Type in command: ");
            playerInput = command.nextLine();
            switch (Integer.parseInt(playerInput)) {

                case 2:

                    System.out.println("Right answer!");
                    player.studyEXP += 2000;
                    break;

                default:

                    System.out.println("Wrong answer!");

            }
            System.out.println("Let’s proceed to the next exam");
            System.out.println(description.FinnishExam);
            System.out.print("Type in command: ");
            playerInput = command.nextLine();
            switch (Integer.parseInt(playerInput)) {

                case 1:

                    System.out.println("Right answer!");
                    player.studyEXP += 2000;
                    break;

                default:

                    System.out.println("Wrong answer!");

            }
            System.out.println(description.finalEvent02);
            System.out.println(description.finalParty);
            System.out.println(description.question01);
            System.out.print("Type in command: ");
            playerInput = command.nextLine();
            switch (Integer.parseInt(playerInput)) {

                case 2:

                    System.out.println("Right answer!");
                    player.socialEXP += 2000;
                    break;

                default:

                    System.out.println("Wrong answer!");

            }
            System.out.println(description.question02);
            System.out.print("Type in command: ");
            playerInput = command.nextLine();
            switch (Integer.parseInt(playerInput)) {

                case 1:

                    System.out.println("Right answer!");
                    player.socialEXP += 2000;
                    break;

                default:

                    System.out.println("Wrong answer!");

            }
            System.out.println(description.question03);
            System.out.print("Type inn command: ");
            playerInput = command.nextLine();

            switch (Integer.parseInt(playerInput)) {

                case 1:

                    System.out.println("Right answer!");
                    player.socialEXP += 2000;
                    break;

                default:

                    System.out.println("Wrong answer!");

            }
            printTitle(time, player);
    }

    public void printHelp() {
        System.out.println(description.help);
    }

    // Printing directions and activities
    public void printer(Player player) {

        System.out.println("");
        //Uncomment next line to print out location description
        //System.out.println(player.currentLocation.printDescription());
        System.out.print("[" + player.getMood() + "]" + "[" + player.currentLocation.getLocationName() + "]" + "[" + time.getTimeNow() + "]" + "[Day: " + time.dayNumber + "]" + "\n");
        System.out.println(player.stats());
        System.out.println("");

        if (checker(player) == 1) {
            if (!player.currentActivity.isFinal() && player.currentActivity == Hold) {
                System.out.println(player.currentLocation.printDescription());
                Collections.shuffle(player.currentLocation.getActivities(), new Random());
                int i = 0;
                for (Activity activity : player.currentLocation.getActivities()) {
                    System.out.println((player.currentLocation.getActivities().indexOf(activity) + 1) + ". " + activity.getDescription("start"));
                    i++;
                    if (i == 4) {
                        break;
                    }
                }
            } else {
                System.out.println(player.currentActivity.getDescription("condition"));
                Collections.shuffle(player.currentActivity.getActivity(), new Random());
                int i = 0;
                for (Activity activity : player.currentActivity.getActivity()) {
                    System.out.println((player.currentActivity.getActivity().indexOf(activity) + 1) + ". " + activity.getDescription("start"));
                    i++;
                    if (i == 4) {
                        break;
                    }
                }
            }
        } else {
            System.out.println(player.currentLocation.printDescription());
            for (Location location : player.currentLocation.getNextLocation()) {
                System.out.println((player.currentLocation.getNextLocation().indexOf(location) + 1) + ". " + location.getLocationName());
            }
        }
        System.out.println("");
    }

    public int checker(Player player) {
        if (player.currentLocation.isFinal()) {
            return 1;
        }
        return 0;
    }

    // Successfully finished activity
    public void executeActivity(Activity activity, Time time, Player player) {
        if (player.previousLocation.isOpen(time.timeNow)) {
            player.currentLocation = player.previousLocation;
        }

        player.increaseStats(player.currentActivity);
        player.socialEXP += (int) formula(player.mood, player.currentActivity.socialEXP, player.charisma);
        player.studyEXP += (int) formula(player.mood, player.currentActivity.studyEXP, player.intelligence);
        player.mood = player.currentActivity.mood;
        time.increaseTime(player.currentActivity.timeChange);

        // Prinnt out EXP changes
        System.out.println(player.currentActivity.getDescription("end"));
        System.out.println("You gained " + (int) formula(player.mood, player.currentActivity.socialEXP, player.charisma)
                + " social EXP" + " and " + (int) formula(player.mood, player.currentActivity.studyEXP, player.intelligence) + " study EXP");

        // Print out stats changes, if any happened
        if (player.currentActivity.bonusINT != 0) {
            System.out.println("You gained " + player.currentActivity.bonusINT + " point of INT.");
        }
        if (player.currentActivity.bonusCHA != 0) {
            System.out.println("You gained " + player.currentActivity.bonusCHA + " point of CHA.");
        }

        player.currentActivity = Hold;
    }

    // Failed activity
    public void failActivity(Activity activity) {
        if (player.previousLocation.isOpen(time.timeNow)) {
            player.currentLocation = player.previousLocation;
        }
        player.mood = false;
        time.increaseTime(1);
        System.out.println(player.currentActivity.getDescription("fail"));
        player.currentActivity = Hold;
    }

    // Executes player’s command depending on his state
    public void command(int command, Player player) {
        if (checker(player) == 1) {
            if (player.currentActivity.isFinal()) {
                if (player.charisma >= player.currentActivity.checkCHA && player.intelligence >= player.currentActivity.checkINT) {
                    try {
                        if (command <= 4) {
                            executeActivity(player.currentActivity, time, player);
                        }
                    } catch (Exception e) {
                        System.out.println("Invalid command. Choose again.");
                    }
                } else {
                    failActivity(player.currentActivity);
                }
            } else {
                if (player.currentActivity == Hold) {
                    player.currentActivity = player.currentLocation.getActivities().get(command - 1);
                    if (player.currentActivity.isFinal()) {
                        if (command <= 4) {
                            command(command, player);
                        } else {
                            System.out.println("Invalid command. Choose again.");
                        }
                    }
                } else {
                    //System.out.println(player.currentActivity.getDescription("start"));
                    player.currentActivity = player.currentActivity.getActivity().get(command - 1);
                    //time.increaseTime(player.currentActivity.timeChange);
                    command(command, player);
                }
            }
        } else {
            if (player.currentLocation.nextLocation.get(command - 1).isOpen(time.timeNow)) {
                player.previousLocation = player.currentLocation;
                player.currentLocation = player.currentLocation.nextLocation.get(command - 1);
            } else {
                System.out.println("You can’t go there right now. It’s closed.");
                time.increaseTime(-1);
            }
        }
    }

    // Adding coefficient for low/high stats
    public double statsConverter(int num) {
        if (num <= 8 && num >= 1) {
            return 0.55 + 0.05 * num;
        } else if (num >= 12 && num <= 20) {
            return 1.5 - 0.05 * (21 - num);
        }
        return 1;
    }

    // Adding mood coefficient
    public double moodConverter(boolean mood) {
        if (mood) {
            return 1;
        }
        return 0.25;
    }
    
    // Calculates amount of granted EXP depending on stats and mood
    public double formula(boolean playerMOOD, int activityEXP, int stat) {
        if (activityEXP >= 0) {
            return activityEXP * statsConverter(stat) * moodConverter(playerMOOD);
        } else {
            return activityEXP * statsConverter(stat) * (moodConverter(playerMOOD) + 1.5);
        }
    }

    public boolean isEligible(Time time) {
        if (time.dayNumber >= 3) {
            return true;
        }
        return false;
    }

    public boolean ifEnoughEXP(Player player) {
        if (player.socialEXP >= 500 && player.studyEXP >= 500) {
            return true;
        }
        return false;
    }

    // Print out player’s title after Final Event
    public void printTitle(Time time, Player player) {
        if (isEligible(time)) {
            if (player.socialEXP >= 6500 && player.studyEXP >= 6500) {

                double change = ((double) (player.socialEXP - player.studyEXP) / (player.socialEXP + player.studyEXP)) * 100;

                if (change < -30) {
                    System.out.println(description.titleWizard);
                    System.exit(0);
                }
                if (change > 30) {
                    System.out.println(description.titleRockStar);
                    System.exit(0);
                }
                if (change > -30 && change < -10) {
                    System.out.println(description.titleKitty);
                    System.exit(0);
                }
                if (change < 30 && change > 10) {
                    System.out.println(description.titleLightOfTheParty);
                    System.exit(0);
                }
                if (change < 10 && change > -10) {
                    System.out.println(description.titleHanahMontana);
                    System.exit(0);
                }
            } else {
                System.out.println(description.titleGio);
                System.exit(0);
            }
        }
    }

    public void printMenu() {
        System.out.println(description.logo);

        System.out.println("========================================\n"
                + "\n"
                + "	     1. Start Game						\n"
                + "\n"
                + "	     2. Help\n"
                + "\n"
                + "	     3. Quit\n"
                + "\n"
                + "========================================" + "\n" + "\n");
    }
}
