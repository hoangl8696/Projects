/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author polinati
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Activity {

    protected int socialEXP;
    protected int studyEXP;
    protected ArrayList<Activity> nextActivity; // List of nested activities
    protected int bonusINT; 
    protected int bonusCHA;
    private String StartingDescription;
    private String ConditionDescription;
    private String EndingDescription;
    private String FailDescription;
    private boolean isFinal; // Checker if this activity is the last
    protected boolean mood; 
    protected ArrayList<Activity> randomActivity; // List of shuffled activities
    protected Random randomizer; 
    protected int checkINT;
    protected int checkCHA;
    protected int timeChange; //Increases time by given number

    // Constructor for non-final activities
    public Activity(boolean checker, boolean mood, int timeChange) {
        this.isFinal = checker;
        this.timeChange = timeChange;
        this.mood = mood;
        this.nextActivity = new ArrayList<Activity>();
        this.randomActivity = new ArrayList<Activity>();
        this.StartingDescription = "";
        this.ConditionDescription = "";
        this.EndingDescription = "";
        this.FailDescription = "";
    }
    
    // Constructor for final activities
    public Activity(int socialEXP, int studyEXP, int bonusINT, int bonusCHA, boolean checker, boolean mood, int timeChange) {
        this.socialEXP = socialEXP;
        this.studyEXP = studyEXP;
        this.bonusINT = bonusINT;
        this.bonusCHA = bonusCHA;
        this.isFinal = checker;
        this.StartingDescription = "";
        this.EndingDescription = "";
        this.ConditionDescription = "";
        this.FailDescription = "";
        this.nextActivity = new ArrayList<Activity>();
        this.mood = mood;
        this.randomActivity = new ArrayList<Activity>();
        this.checkINT = this.checkCHA = 0;
        this.timeChange = timeChange;
    }

    public Activity(int socialEXP, int studyEXP, int bonusINT, int bonusCHA, boolean checker, boolean mood, int timeChange, int checkINT, int checkCHA) {
        this.socialEXP = socialEXP;
        this.studyEXP = studyEXP;
        this.bonusINT = bonusINT;
        this.bonusCHA = bonusCHA;
        this.isFinal = checker;
        this.StartingDescription = "";
        this.ConditionDescription = "";
        this.EndingDescription = "";
        this.FailDescription = "";
        this.nextActivity = new ArrayList<Activity>();
        this.mood = mood;
        this.randomActivity = new ArrayList<Activity>();
        this.checkINT = checkINT;
        this.checkCHA = checkCHA;
        this.timeChange = timeChange;
    }

    // Shuffles list of activities
    public void shuffleList() {
        this.randomActivity.clear();
        for (Activity activity : this.nextActivity) {
            this.randomActivity.add(activity);
        }
        Collections.shuffle(this.randomActivity);
    }

    public void addNextActivity(Activity nextActivity) {
        this.nextActivity.add(nextActivity);
    }

    public ArrayList<Activity> getActivity() {
        return this.nextActivity;
    }

    public int getEXP(String type) {
        if (type.equals("social")) {
            return this.socialEXP;
        } else if (type.equals("study")) {
            return this.studyEXP;
        }
        return 0;
    }

    public int getBonusPoints(String type) {
        if (type.equals("INT")) {
            return this.bonusINT;
        } else if (type.equals("CHA")) {
            return this.bonusCHA;
        }
        return 0;
    }

    public void setDescription(String description, String type) {
        if (type.equals("start")) {
            this.StartingDescription += description;
        } else if (type.equals("end")) {
            this.EndingDescription += description;
        } else if (type.equals("condition")) {
            this.ConditionDescription += description;
        } else if (type.equals("fail")) {
            this.FailDescription += description;
        }
    }

    public String getDescription(String type) {
        if (type.equals("start")) {
            return this.StartingDescription;
        } else if (type.equals("end")) {
            return this.EndingDescription;
        } else if (type.equals("condition")) {
            return this.ConditionDescription;
        } else if (type.equals("fail")) {
            return this.FailDescription;
        }
        return "";
    }

    public boolean isFinal() {
        return this.isFinal;
    }
}
