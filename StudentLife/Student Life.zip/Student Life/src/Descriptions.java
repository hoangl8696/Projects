/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author polinati
 */

// Hides all long descriptions 

public class Descriptions {

    public String l = System.getProperty("line.separator");

    public String finalEvent = l + ". . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .\n"
            + ".	        The year is coming to an end and you have your final exams coming up!                   .\n"
            + ".	A popular end of year party is also coming up! This is your last chance to collect XP.          .\n"
            + ". . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ." + l;

    public String finalEvent02 = l + ". . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .\n"
            + ".	                                    Exams are over!                                             .\n"
            + ".	                             Now it’s time to party hard!                                       .\n"
            + ". . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ." + l;

    public String MathExam = l + "Math exam." + l + "How many letters in this sentence?" + l + l + "1. 28" + l + "2. 8" + l + "3. 29" + l;

    public String GamesExam = l + "Games exam." + l + "Finish the code:" + l + l + "if(!this.Kill(me))" + l + "1. kill.this();" + l + "2. me.Strength++;" + l + "3. me.kill(me);" + l;

    public String FinnishExam = l + "Finnish exam." + l + "Translate into English: " + l + "Juoksentelisinkohan?" + l + l + "1. I wonder if I should run around aimlessly?" + l + "2. Should I run using a head as a third leg?" + l + "3. Does he have all the Moomins in the valley?" + l;

    public String finalParty = l + "You are invited to a facebook event by a friend with the title “EPIC Final Party”. This is\n"
            + "the most popular party of the year and everybody is going. There are at least 200 people invited\n"
            + "and 100 of them are going. There will be drinking, dancing and a lot of “socializing”.\n"
            + "Nearly your entire class is going and with a click of a button you say you are going too." + l;

    public String question01 = l + "On the night of the party, you take a train to Helsinki and when you reach the station\n"
            + "you find your friend. He asks you “Hey, whose party are you going to?” You don't want\n"
            + "to seem uncool so you have to tell him who is hosting the party. You say:" + l + l + "1. Dan" + l + "2. Shazam" + l + "3. Miguel" + l + "4. Calvin" + l;
    
    public String question02 = l + "You arrive at the clubroom and every inch of the room is filled with drunk people.\n"
            + "There is spilt beer all over the floor, someone vomiting in the balcony, drunk couples\n"
            + "making out on the couch. You open your can of beer and join the party. F*cking\n"
            + "Heisenberg approaches you and starts talking to you like you have met before.\n"
            + "Quick! You need to remember what his real name is. Is it:" + l + l + "1. Vo Hyunh Quang Nguyen" + l + "2. Phuc Hyunh Duc Nyuyen" + l + "3. Chanh Hung Tran" + l + "4. Quang Duc Nguyen" + l;
    
    public String question03 = l + "You just finished your last can of beer and you in the dire need of another drink so you\n"
            + "head over to the bar in the clubroom and just then a drunkard mistakes you for the\n"
            + "bartender and asks you to make them a “Hangman's blood”. You have to figure out the\n"
            + "exact components in the drink to make it perfectly. You mix:" + l + l + "1. Gin, Whiskey, Rum, Port and Brandy" + l + "2. Absinthe and Milk" + l + "3. Champagne, Rum, Whiskey and Brandy" + l + l;
    
    public String titleLightOfTheParty = l + "You are slightly popular yet smart! You attended nearly every party all year but\n"
            + "also managed to get decent grades too! You spent a little too much time partying than\n"
            + "studying so your grades could have been better. " + l;

    public String titleKitty = l + "Meeooowww meoow meow mmmeeeowww meeowww!!!.......Prrprrrprr...! Meoow meooowww meowww...." + l;

    public String titleRockStar = l + "Where there is a party, you are always found drinking hard with your friends!! Everybody from all\n"
            + "campuses know who you are and how much you love to party. Your parties are known to be “EPIC”.\n"
            + "Unfortunately, you did not give much attention to your studies so you failed most of your courses\n"
            + "and you may have to repeat the courses again next year. But you have had a heck of a year with tonnes\n"
            + "of drunken memories most of which you don't remember." + l;

    public String titleWizard = l + "You are a Wizard! You aced all your tests and know everything there is to know about programming.\n"
            + "You spent all year buried in books and homework and forgot to socialize and relax. Though you don't have much friends,\n"
            + "you still have the company of your books." + l;

    public String titleHanahMontana = l + "Here we go! “Mix it all together and you know you got the BEST OF BOTH WORLDS! Hahahaha”\n"
            + "Congratulations!!! You have had led a perfect year and managed to successfully juggle social life\n"
            + "and study life!\n"
            + "You have tonnes of friends and also kept your grades up at the same which is something most students can't do!" + l;

    public String titleGio = l + "Gio! Congratulations! You are officially a Giovanni Tancredi Legname.\n"
            + "You didn't care at all about your XP and were too lazy to do any useful activities. On the bright side,\n"
            + "you can't participate in this year's Vappu event so you have plenty of time to relax and sleep more.\n"
            + "Happy sleeping, Gio!" + l;

    public String danceRobotically = l + "You bust out the moves you’ve learnt on youtube. You try to imitate the moves exactly how\n"
            + "you saw it and keep repeating. This seems really robotic and you hear someone shout\n"
            + "“Quit dancing like Alex”. Confused who this Alex person is, you stop right away. " + l;

    public String danceWildly = l + "You let the music move your body and you dance energetically. You have a blast and you feel\n"
            + "extraordinarily happy." + l;

    public String dancePretend = l + "You don’t particularly feel in the dancing mood. Everyone else seems so into it that you decide\n"
            + "to give it a try and at least try to dance so you don’t spoil the mood for everyone else.\n"
            + "You move your hands a little, try imitating someone else, move around with no energy.\n"
            + "Not the best dance experience you had." + l;

    public String drugs = l + "You don’t have much energy to dance and not feeling it. Your swiss friend offers you some snuff\n"
            + "to help you. You sniff it and it immediately gives you a burst of energy and a headache too!\n"
            + "You start flying off the dance floor with your fast energetic moves. (Don’t do drugs, kids)" + l;

    public String dancefloor = l + "It’s time for some real party! You hit the dance floor and it is crowded with people dancing\n"
            + "to an upbeat music. You can:" + l;
    
    public String cook = l + "You were feeling bloody hungry. So you cooked the fool pan of rice and meatballs with a spicy sauce." + l;
    
    public String play = l + "Half-Life 3 is finally out! You couldn’t miss this. For the last 4 hours you totally forgot about\n"
            + "everything and just enjoyed the game." + l;
    
    public String ginger = l + "You spot a very attractive ginger haired girl. You dance casually next to her and she responds positively.\n"
            + "You two hit it off and have a great time. Congratulations!" + l;

    public String gingerFail = l + "You try your best dance moves with her but they are so awkward and robotic it seems a little desperate.\n"
            + "She gives you a disgusted look and moves away. You follow her around and she finally\n"
            + "just pushes you away. Disappointed, you give up and leave. Sorry, you do not have\n"
            + "enough charisma to get her." + l;

    public String orangeCoverallFail = l + "You tried your best moves on him. Nothing worked. Afterall a girl with long hair and\n"
            + "two glasses of beer appeared right next to him. Ooops, apparently he already has a girlfriend." + l;
    
    public String provocative = l + "Feeling a bit nervous, you muster up the courage to talk to her. You two have flirty\n"
            + "exchanges and you end up convincing her to dance with you. You dance for a while\n"
            + "and the rest is not meant to be described. Congratulations! Mission Accomplished!\n"
            + "You feel extra happy and feel more confident than before." + l;

    public String provocativeFail = l + "You try approaching her but she does not seem to acknowledge your presence then you blurt\n"
            + "out a really inappropriate opening line. She looks at you with extreme disgust, throws her\n"
            + "drink on your face and tells you to leave. Oops! Sorry, you did not have enough charisma\n"
            + "to accomplish this mission. She was hard to get anyway. " + l;

    public String upsetGirl = l + "You casually walk up to her and start a conversation by asking her why she is upset. You both\n"
            + "have a good talk, you even manage to make her feel better about whatever it was that upset her.\n"
            + "You two have a good time dancing and what else happened that night is not suitable to describe\n"
            + "in this pg-13 game." + l;

    public String upsetGirlFail = l + "You walk up to her and exclaim that she looks ugly when she is upset and she should smile.\n"
            + "Deeply offended by your comment, she curses you and leaves. Oops! Missions failed. You could not\n"
            + "even get the easy one, tough luck. Better luck next time!" + l;

    public String Kha = l + "You took one look at him and noticed how weird he is. Without further ado you immediately leave\n"
            + "without a second glance praying he does not come up to you. You feel a little confident that you\n"
            + "were able to weed out the bad ones." + l;

    public String KhaFail = l + "All you needed to do was look in his direction to get him wrapped around your finger (not literally!).\n"
            + "He seemed really twitchy and kept mumbling to himself. That really creeped you out but you had\n"
            + "your beer goggles on and did not know what you were thinking when you approached him. You regret\n"
            + "wasting your time on him and feel a little less confident." + l;

    public String guyHat = l + "There was a different air around this guy. He wore one of those grandpa hats which most people\n"
            + "don’t wear nowadays. It reminds you of Ryan Gosling from The Notebook, your pre-teen crush.\n"
            + "You start talking to him and he seems really talkative and social. Mission Accomplished!" + l;

    public String guyHatFail = l + "You try talking to him but he doesn’t answer. I guess it’s a finnish thing. You don’t have\n"
            + "enough charisma to start an interesting conversation with him. Mission failed." + l;

    public String suit = l + "You say a simple hello to this guy and you two immediately start conversing about\n"
            + "intellectual things. He explains new programming terminology you have not heard before.\n"
            + "Moreover,he invited you to an upcoming Slush event, where tech talent can meet with top-tier\n"
            + "international investors." + l;

    public String suitFail = l + "You start talking to him but all he says is so complicated and way more advanced than what you know\n"
            + "that you feel extremely dumb and end up asking stupid questions. He looks at you with a “errr” look and walks away.\n"
            + "Sorry you did not have enough intelligence." + l;

    public String gamesQuestion = "A programmer's wife one day asked her husband: Can you go to the shop and buy a loaf of bread and if\n"
            + "they have eggs, buy six. What did her husband buy?";

    public String callFriend = "Who says calling someone is a lost art? Not for you it isnt. You scroll through your contact list and tap\n"
            + "on the friend you desperately need to talk to. You have a nice long chat about life and what's up with\n"
            + "both of you before you hang up. Talking is always more personal than just texting and makes you more\n"
            + "social in a way." + l;
    
    public String NineGAG = l + "You didn’t notice how the time passed and class ended nor you remember what the teacher was talking about.\n"
            + "However, now you know how to gift-wrap a cat." + l;
    
    public String Hearthstone = l + "You challenge your friend who sits at the opposite corner of the room and next hour you spend figuring\n"
            + "out who is stronger. Suddenly, it’s a tie!" + l;
    
    public String catVideos = l + "Cats are so funny and adorable :’D. You can never get enough of kitties :’) You don’t gain anything from\n"
            + "this but you feel so happy! ^_^ Prrr..." + l;

    public String chatFriends = "It’s always nice to catch up with what's going on with your friends. You talk about the weirdest things\n"
            + "and if anyone were to read your conversations they'd think you are crazy. After hours of chatting about\n"
            + "fat cat babies and meth, you bid your buddies farewell and think about what to do next." + l;

    public String homework = "So many assignments and the deadlines are so close! You look through tuubi and start completing\nassignments "
            + "due soon. Though it was not that easy, you feel rather content with all the assignments\n"
            + "you managed to return before the deadline. Plus, you have also learned quite a lot." + l;

    public String sleep = "It has been a tiring day and a good nap is in order so you crawl into your comfortable,\n"
            + "warm bed and have an exquisite nap under the warmth of your blanket forgetting about the worries of\n"
            + "the day. You wake up feeling fresher than ever." + l;

    public String clean = "Well its about time you did! Your house is a mess, atleast to you. You grab your cleaning tools which\n"
            + "you keep safely in a closet and get ready for some cleaning to be done. You neatly put away all the\n"
            + "stray things lying around, vacuum clean the entire house, wash all the dishes and even leave the kitchen\n"
            + "counters and stove spotless. After all the dirty work has been done, you mentally pat yourself on the back\n"
            + "content with what you have done. " + l;

    public String procrastinate = "Congratulations! You have just accomplished nothing in the last few hours! Something more than half \n"
            + "the world suffer from! Atleast you thought of doing something, its the thought that counts right?\n"
            + "Well you did scroll through dozens of pages on facebook, check nearly every photo upload on instagram\n"
            + "and watch tonnes of funny cat videos on Youtube! That has to be some sort of achievement.\n"
            + "Unfortunately not in this game." + l;
    
    public String talkToFlatmate = l + "You walk into the familiar apartment you call home and notice everything is just the way you left it.\n"
            + "With a huge sigh of relief that your roommate hasn't ruined the perfect order that you keep your\n"
            + "apartment in, you walk into your room and think about what you can do while you are at home." + l;

    public String shower = "Wet floor become Broadway, shower head is your microphone, and your flat mates are audiences.\n"
            + "Let’s the show begin!" + l;

    public String forest = "Forests are everywhere in Finland. You walk to a nearby forest and take a hike through the natural\n"
            + "green trees. You find a quiet spot on to sit and sip hot tea while enjoying the nature around you.\n"
            + "You forget all the worries of the world and feel at peace. You sit there for a good amount of time\n"
            + "and decide it is time you go back home. You now feel light and elated." + l;

    public String Robot = "Building a robot is in and of itself is fun and educating. After a few hours it works and you feel so proud of yourself." + l;

    public String metropolia = "You buzz in your magnetic key and enter Metropolia through the B building. There is barely anyone" + l
            + "around just the occasional 2-3 students that walk across. Right ahead of you is the library which" + l
            + "looks rather peaceful. You know that to get to the cafeteria you have to go to the left. Also, to" + l
            + "your right is a staircase that leads up to the classrooms." + l;
            
    public String library = l + "You quietly walk into the library and look around. The library is silent with a few\n"
            + "students sitting and reading or using the computers. The librarian sitting at a desk to\n"
            + "your left, there are shelves filled with books right ahead of you, to your right there are\n"
            + "large tables with many seats around it possibly for team projects and there are also a\n"
            + "few computers available for use." + l;
    
    public String read = "The library is filled with shelves laden with books on just about anything. You walk\n"
            + "in between the shelves scanning for books that look interesting. There are a few books that catch your\n"
            + "eye and you make a mental list of them. You can choose to read:" + l;
    
    public String book = l + "This worth it. You feel that you spend these hours with a great benefit. Today you’re defenitely\n"
            + "going to sleep smarter than you woke u in the morning." + l;
    
    public String Tiger = l + "Tiger is one of the most popular night clubs in Helsinki and so you are not surprised by\n"
            + "how long the queue is at the entrance. After getting your ID checked, you go up to\n"
            + "where the real party is. Tiger, like any other club, is extremely loud and packed with\n"
            + "drunken people. You notice a bar to your right where you can buy all sorts of drinks.\n"
            + "Right ahead of you is a huge dance floor filled with people dancing to an upbeat music.\n"
            + "There are also some places to sit and meet new people diagonally to your right. You can:" + l;
    
    public String bar = l + "There is a long line of people buying a drink and when it is finally your turn you call the\n"
            + "bartender. He asks you what drink you want. You say:" + l;
    
    public String home = l + "You walk into the familiar apartment you call home and notice everything is just the way you\n"
            + "left it. With a huge sigh of relief that your roommate hasn't ruined the perfect order\n"
            + "that you keep your apartment in, you walk into your room and think about what you can do\n"
            + "while you are at home." + l;
    
    public String MathClassroom = l + "You buzz in and enter the class to find the class packed with students. Apparently,\n"
            + "Mito is the best mathematics teacher in all of Metropolia and maybe even the country.\n"
            + "You scan the class for a vacant seat and find one that is somewhat far from the board.\n"
            + "Disappointed, you pull the chair to the table and take out your notebook ready to write notes.\n"
            + "At this point, you can:" + l;
    
    public String FinnishClassroom = l + "You enter the finnish class and are greeted by Suoma-riita with “Huomenta!”.\n"
            + "You reply with “Huomenta” in return. There is a really friendly atmosphere in the class\n"
            + "and you are ready to learn Finnish. She then instructs the class “Seurava Kappale kahdeksan”.\n"
            + "It takes you a second to understand it and you immediately turn to chapter 9. You can:" + l;
    
    public String GamesClassroom = l + "You enter the class and everyone seems to be on their laptops typing away,\n"
            + "probably working on their Java MOOC exercises or on their game project. You grab a seat\n"
            + "and also turn on your laptop. You can:" + l;
    
    public String cafeteria = l + "You walk across the hallway to the left and enter the lobby. You look to your right and\n"
            + "see the cafeteria filled with hungry students. You join the queue at the entrance and\n"
            + "when it is your turn you stack up your tray with food. The food doesn't look particularly\n"
            + "good, the same type of food as always. With a tray full of food in your hands, you\n"
            + "look around the busy cafeteria thinking of what to do. You can:" + l;
    
    public String libraryHomework = l + "You have a load of homework and the library is the best place to get some peace and quiet with no\n"
            + "distractions so you get quite a lot of homework done and in the most efficient way. " + l;

    public String talkLibrarian = "There is not much to talk to the librarian about but you walk up to her anyway and hope to start a fun\n"
            + "conversation. All you talk about is how to use the photocopy machines and how to borrow books etc. Not\n"
            + "really all that fun but hey atleast you tried. " + l;

    public String eatAlone = "You find a table with only one seat empty and you decide to sit there. You eat your lunch in peace without no\n"
            + "disturbances. You like not talking while you are enjoying your food.Carrot is red, pen ink is blue,\n"
            + "food on your homework, sucks to be you" + l;

    public String thirdYear = l + "You start talking to him and he is really smart. You contribute a lot to his topics and you two have\n"
            + "a blast talking about the latest hackathons and improvements in the IT field. You have made a new friend." + l;

    public String thirdYearFail = l + "You try talking to him but it seems like he is speaking another language because you have no idea\n"
            + "what he is talking about. You end up just nodding with a blank face that really repels him. Sorry you\n"
            + "don’t have enough intelligence to engage in intellectual conversations with him." + l;

    public String sitItalian = l + "You sit across him hoping to start a conversation but he is too busy listening to music and is\n"
            + "apparently too lazy to talk. Well that was a waste of time!" + l;

    public String sitVietnamese = l + "You put your tray down across him and ask his name, he says it’s Liam And that’s all the conversation\n"
            + "you have because he is too busy texting his girlfriend on his phone. Well that was a waste of time!" + l;

    public String sitDarkHair = l + "You sit next to her and make some small talk with her. Soon you two become well acquainted and\n"
            + "congratulations you made a new friend." + l;
    
    public String sitDarkHairFail = l + "You sit next to her and try talking to her but you end up asking the weirdest questions that make her\n"
            + "feel uncomfortable. There is a really awkward silence and you really don’t know what to say. Sorry you\n"
            + "don’t have enough charisma to make friends with her yet. " + l;
    
    public String danceWithFriend = "Switch this game tab to Youtube, copy this link: https://www.youtube.com/watch?v=PcEnu-Am7Jo, let’s dance!" + l;

    public String help = "HOW TO PLAY THE GAME?\n"
            + "\n"
            + "Playing Student Life is super easy!\n"
            + "When you enter any location, you will be given a list of things you can do. All you have to do is type\n"
            + "the NUMBER corresponding to the activity you wish to choose. Simple as that. \n"
            + "\n"
            + "If at any point you want to quit the game, type “quit”.\n" + l
            + "HOW TO WIN?\n" + l
            + "In Student Life, you can move around locations (Home, Metropolia or Tiger Club) and do various activities\n"
            + "around the min-world. You gain two types of XP from doing these activities, SocialXP from social activities\n"
            + "and StudyXP from study activities. But beware some activities can make you LOSE XP so be careful of your\n"
            + "choices.\n"
            + "The main aim of the game is to have at least (5000) SocialXP and (5000) StudyXP by (20) days to be eligible\n"
            + "for the special final Vappu event.\nWhen you start the game, you will have to choose between three types of students: Nerd , Party Animal\n"
            + "or Typical.\n"
            + "\n"
            + "You have two types of stats, Intelligence and Charisma. You will have different levels of these stats\n"
            + "initially depending on which student type you choose. So if you choose “Nerd” you will have more\n"
            + "Intelligence than charisma (in the beginning!).\n"
            + "You gain more StudyXP if you have more intelligence and more SocialXP if you have more charisma! \n"
            + "You will gain Intelligence and Charisma from very special activities throughout the game.\n"
            + "At the end of the game you will have a brand new student titles depending on your SocialXP and StudyXP!\n"
            + "So you can start out as a party animal and end up as a true nerd!\n" + l
            + "MOOD\n" + l
            + "You will also have to pay attention to your MOOD. You have good mood and bad mood. Some activities can\n"
            + "make you sad :( so to be happy do happy activities :)\n"
            + "You gain more XP from activities if you are happy! On the other hand, you gain less XP if you are sad." + l;

    public String logo = "                                      */                                                           \n"
            + "                            ,///*  ////*                                                           \n"
            + "                  ,////  ,////*.*///                                                               \n"
            + "                /////*/////,   ///                                                                 \n"
            + "              ////   .///    *//,.                                                                 \n"
            + "            ////    *///    (//,,                                                                  \n"
            + "           ////    (//,,   ((/.,,                                                                  \n"
            + "          ///     ((/,,,  ((( ,,    &@@@@@, @@@@@@@@ @@%  ,@@  @@@@@@@   @@@@@@  @@@   @@ @@@@@@@@,\n"
            + "         (//     ((* ,,  #(( ,,     @@&        @@    @@%  ,@@  @@    @@  @@      @@,@* @@    @@%   \n"
            + "        (//     ((/ ,,   (( ,*        &@@@@    @@    @@%  ,@@  @@    @@  @@%%%%  @@ .@(@@    @@%   \n"
            + "       ((/     #((  ,,  /(/**       @@  ,@@    @@    #@@  @@#  @@    @&  @@      @@   @@@    @@%   \n"
            + "      (((     ##(  **    **          ,@@@,     @@      #@@@#   @@@@@@@   @@@@@@  @@    @@    @@%               \n"
            + "      ((      #(/ **                                                                               \n"
            + "     (((      /((/                                                                                 \n"
            + "    .((                                              @@     @@@  @@@@@@  @@@@@@                    \n"
            + "    #(*                                              @@     @@@  @@      @@                        \n"
            + "    ((                                               @@     @@@  @@@@@@  @@@@@@                    \n"
            + "   #((                                               @@     @@@  @@      @@                        \n"
            + "   #(                                                @@@@@@ @@@  @@      @@@@@@                   \n"
            + "   #(                                                                                              " + l + l;

}
