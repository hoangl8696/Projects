/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author polinati
 */

//need refactoring

import java.util.ArrayList;
public class Time {
    protected String timeNow;
    protected ArrayList<String> time; // Stores day times
    protected int dayNumber; 
    
    public Time ()
    {
        this.time = new ArrayList<String>();
        this.time.add ("Morning");
        this.time.add ("Day");
        this.time.add ("Evening");
        this.time.add ("Night");
        this.timeNow = this.time.get(0);
        this.dayNumber = 1;
    }
    
    public Time (String time)
    {
        this ();
        this.timeNow = time;
    }
    
    public void increaseTime ()
    {
        if (this.time.indexOf(this.timeNow)==3)
        {
            this.timeNow = this.time.get(0);
            this.dayNumber++;
        }
        else
        {
            this.timeNow = this.time.get(this.time.indexOf(this.timeNow)+1);
        }
    }
    
    public void increaseTime (int numberOfTimes)
    {
        for (int i = 0; i<numberOfTimes; i++)
        {
            increaseTime();
        }
    }
    
    public String getTimeNow ()
    {
        return this.timeNow;
    }
    
    public int getDayNumber(){
        return this.dayNumber;
    }
    
}